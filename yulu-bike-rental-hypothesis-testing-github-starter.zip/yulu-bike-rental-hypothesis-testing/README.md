# Yulu Bike Rental Analysis — Hypothesis Testing

## Project Overview
This project analyzes bike-rental demand for Yulu, a shared electric-bike mobility service. The objective is to identify factors that influence total rentals (`count`) and understand how environmental and calendar-related variables relate to demand.

The report uses bivariate analysis and statistical hypothesis-testing techniques to compare groups and investigate relationships.

## Business Objectives
- Understand factors affecting bike-rental demand.
- Explore relationships between weather, season, working-day status, and rental counts.
- Compare populations using statistical tests.
- Translate analytical observations into business insights.

## Dataset
The report describes a dataset containing **10,886 rows and 12 columns**, with no missing values reported.

Variables include:
- Categorical: `season`, `holiday`, `workingday`, `weather`
- Numerical: `temp`, `humidity`, `windspeed`, `count`

## Tools and Techniques
- Python
- Pandas and NumPy
- Exploratory Data Analysis (EDA)
- Bivariate analysis
- Data visualization
- Two-sample t-test
- ANOVA
- Chi-square test
- Hypothesis testing

## Analysis Performed
1. Dataset overview and data-type inspection.
2. Distribution analysis of numerical variables.
3. Season and weather distribution analysis.
4. Working-day versus non-working-day rental comparison.
5. Season-wise and weather-wise rental comparisons.
6. Hypothesis testing using two-sample t-tests, ANOVA, and Chi-square tests.

## Findings Reported
- The `count` variable has a right-skewed distribution: lower rental counts are more frequent, while high-demand observations occur less often.
- The report describes the dataset as fairly balanced across seasons.
- Most weather observations fall under clear or favorable conditions; adverse weather is less frequent.
- The report observes higher median rental counts on working days than non-working days.
- Rental demand varies across seasons.
- The report observes lower rental demand under worse weather conditions.

## Business Relevance
Understanding how demand varies with weather, season, and working-day status can help a bike-sharing business plan fleet availability and operational capacity. The detailed report contains the analysis, visualizations, test work, and conclusions.

## Repository Structure
```text
yulu-bike-rental-hypothesis-testing/
├── README.md
└── report/
    └── Yulu_Hypothesis_Testing_Report.pdf
```

## Project Report
See [`report/Yulu_Hypothesis_Testing_Report.pdf`](report/Yulu_Hypothesis_Testing_Report.pdf) for the full project report.

## Reproducibility Note
This starter repository currently contains the report and README only. Add the original Jupyter Notebook (`.ipynb`) and dataset (`.csv`) to make the analysis reproducible. Check the dataset's license and terms before publishing it publicly.

## Author
**Mohd Zamman Mohd Mubeen Khan**  
BBA Graduate | Aspiring Data Analyst
